AdvancedParticleSystem

Check out wiki page! https://github.com/Limekys/AdvancedParticleSystem/wiki/Main
